import React from "react";
import Script from "next/script";
import { HeroSectionV3 } from "@/components/sections/hero-section-v3";
import { ProblemSectionV2 } from "@/components/sections/problem-section-v2";
import { BeforeAfterSection } from "@/components/sections/before-after-section";
import { DecisionOutputSection } from "@/components/sections/decision-output-section";
import { HowItWorksHorizontal } from "@/components/sections/how-it-works-horizontal";
import { ScreenshotAnnotationSection } from "@/components/sections/screenshot-annotation-section";
import { FeaturesSection } from "@/components/sections/features-section";
import { DifferentiatorSection } from "@/components/sections/differentiator-section";
import { SecuritySection } from "@/components/sections/security-section";
import { TestimonialsSectionV3 } from "@/components/sections/testimonials-section-v3";
import { PricingSectionV3 } from "@/components/sections/pricing-section-v3";
import { FaqSectionV2 } from "@/components/sections/faq-section-v2";
import { CtaSectionV3 } from "@/components/sections/cta-section-v3";
import { NavigationV2 } from "@/components/sections/navigation-v2";
import { CustomCursor } from "@/components/shared/custom-cursor";
import { ScrollProgress } from "@/components/shared/scroll-progress";

export default function LandingPageV3() {
  const jsonLdProduct = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "NDA Agent",
    "description": "An AI tool for reviewing NDAs and identifying legal risks securely on your local machine.",
    "applicationCategory": "BusinessApplication",
    "operatingSystem": "Web",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    }
  };

  const jsonLdFaq = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Is this legally reliable? Can I trust the AI's analysis?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "KR8V uses advanced NLP models trained on thousands of NDAs to identify risk patterns. However, we're clear: this is decision support, not legal advice."
        }
      },
      {
        "@type": "Question",
        "name": "Where does my data go? Who can see my contracts?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Nowhere. Your contracts are processed entirely on your infrastructure using local AI models. We don't have external API calls."
        }
      }
    ]
  };

  const jsonLdBreadcrumb = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://ndaagent.com/"
    }]
  };

  return (
    <>
      <Script
        id="schema-product"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdProduct) }}
      />
      <Script
        id="schema-faq"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdFaq) }}
      />
      <Script
        id="schema-breadcrumb"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdBreadcrumb) }}
      />
      <main className="relative bg-background overflow-hidden">
        <CustomCursor />
        <ScrollProgress />
        <NavigationV2 />
        
        {/* Hero with Decision Preview */}
        <HeroSectionV3 />
        
        {/* Problem with Real NDA Snippet */}
        <ProblemSectionV2 />
        
        {/* Before/After Comparison */}
        <BeforeAfterSection />
        
        {/* Decision Output Feature (NEW - Hook Feature) */}
        <DecisionOutputSection />
        
        {/* How It Works (Horizontal Scroll) */}
        <HowItWorksHorizontal />
        
        {/* Screenshot with Annotations (Visual Variety) */}
        <ScreenshotAnnotationSection />
        
        {/* Features (Cards - but different from others) */}
        <FeaturesSection />
        
        {/* Differentiator */}
        <DifferentiatorSection />
        
        {/* Security */}
        <SecuritySection />
        
        {/* Testimonials (Ultra-Specific) */}
        <TestimonialsSectionV3 />
        
        {/* Pricing (Safe Copy) */}
        <PricingSectionV3 />
        
        {/* FAQ */}
        <FaqSectionV2 />
        
        {/* CTA (Aggressive Action) */}
        <CtaSectionV3 />
      </main>
    </>
  );
}

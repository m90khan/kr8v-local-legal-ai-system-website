"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Card } from "@/components/ui/card";
import {
  FileText,
  Brain,
  Shield,
  Layers,
  GitBranch,
  Target,
  Zap,
  Lock,
  Users,
  TrendingUp,
} from "lucide-react";

const today = [
  {
    icon: FileText,
    title: "NDA Review",
    description: "Instantly analyzes 50+ clause types in seconds",
    status: "Live",
    metric: "10 sec avg",
  },
  {
    icon: Brain,
    title: "Risk Detection Engine",
    description: "Pattern recognition across thousands of contracts",
    status: "Live",
    metric: "95% accuracy",
  },
  {
    icon: Shield,
    title: "Decision Intelligence",
    description: "Clear recommendations: Safe, Review, or High Risk",
    status: "Live",
    metric: "3 risk levels",
  },
];

const roadmap = [
  {
    icon: Layers,
    title: "Contract Lifecycle Management",
    description: "Track contracts from draft to signature to renewal",
    phase: "Next",
    color: "from-primary to-chart-2",
  },
  {
    icon: Brain,
    title: "Multi-Document Reasoning",
    description: "Compare NDAs against master agreements and related contracts",
    phase: "Coming next",
    color: "from-chart-2 to-chart-3",
  },
  {
    icon: Target,
    title: "Policy Compliance Engine",
    description: "Automated compliance checks across regulations and company policy",
    phase: "Expanding into",
    color: "from-chart-3 to-chart-4",
  },
  {
    icon: Users,
    title: "AI Legal Assistant",
    description: "Natural language contract queries and clause explanations",
    phase: "Beyond NDAs",
    color: "from-chart-4 to-chart-5",
  },
  {
    icon: GitBranch,
    title: "Workflow Automation",
    description: "Automatic routing, approvals, and stakeholder notifications",
    phase: "Next phase",
    color: "from-chart-5 to-primary",
  },
];

const philosophy = [
  {
    icon: Lock,
    title: "Local-First AI",
    description: "Ollama, on-device models, self-hosted infrastructure. Your contracts never leave your network.",
    principle: "Privacy by Architecture",
  },
  {
    icon: Shield,
    title: "Zero Data Exposure",
    description: "No external API calls. No model training on your data. No third-party access. Ever.",
    principle: "Guaranteed Security",
  },
  {
    icon: Zap,
    title: "Augment, Not Replace",
    description: "We automate document review, not legal judgment. Lawyers focus on strategy, not reading.",
    principle: "AI-Assisted Intelligence",
  },
];

export default function VisionPageV3() {
  const heroRef = useRef<HTMLDivElement>(null);
  const whyRef = useRef<HTMLDivElement>(null);
  const todayRef = useRef<HTMLDivElement>(null);
  const roadmapRef = useRef<HTMLDivElement>(null);
  const philosophyRef = useRef<HTMLDivElement>(null);

  const whyInView = useInView(whyRef, { once: true, margin: "-100px" });
  const todayInView = useInView(todayRef, { once: true, margin: "-100px" });
  const roadmapInView = useInView(roadmapRef, { once: true, margin: "-100px" });
  const philosophyInView = useInView(philosophyRef, { once: true, margin: "-100px" });

  return (
    <main className="relative bg-background min-h-screen">
      {/* Hero Section */}
      <section ref={heroRef} className="py-32 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(120,119,198,0.1),rgba(255,255,255,0))]" />
        
        <div className="container mx-auto max-w-6xl relative z-10">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <span className="text-sm font-medium text-primary">Product Vision</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              From NDA review to a
              <br />
              <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
                private AI system for legal decisions
              </span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-8">
              It starts with NDAs. But it doesn't stop there.
            </p>
            <motion.div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-primary/20"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
            >
              <Lock className="w-4 h-4 text-primary" />
              <span className="text-sm">Runs locally. Your contracts never leave your system.</span>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Why This Matters */}
      <section ref={whyRef} className="py-20 px-6 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={whyInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold mb-6">Why Legal AI Needs to Be Private</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              This isn't just our opinion. It's the only logical path forward.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: TrendingUp,
                title: "Cloud AI = Risk",
                description: "Every contract sent to external APIs creates data exposure. Legal documents contain the most sensitive business information.",
              },
              {
                icon: Shield,
                title: "Legal = High Sensitivity",
                description: "NDAs, contracts, and agreements contain trade secrets, financials, and strategic plans that must never be compromised.",
              },
              {
                icon: Layers,
                title: "Current Tools = Fragmented",
                description: "Teams juggle document management, manual review, and external counsel. No unified system exists.",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                animate={whyInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.15 }}
              >
                <Card className="p-6 border-2 border-border h-full">
                  <item.icon className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    {item.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            className="mt-12 text-center p-8 rounded-2xl bg-gradient-to-br from-primary/10 to-chart-2/10 border-2 border-primary/20"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={whyInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <p className="text-2xl font-bold mb-2">
              KR8V is the only logical solution.
            </p>
            <p className="text-muted-foreground">
              Private infrastructure. Local AI. Complete control.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Where We Are Today */}
      <section ref={todayRef} className="py-20 px-6">
        <div className="container mx-auto max-w-6xl">
          <motion.div
            className="mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={todayInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold mb-4 text-center">Where We Are Today</h2>
            <p className="text-xl text-muted-foreground text-center">
              The foundation is built. NDA review that actually works.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {today.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                animate={todayInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 + 0.2 }}
              >
                <Card className="p-6 h-full border-2 border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                      <item.icon className="w-6 h-6 text-primary" />
                    </div>
                    <span className="px-3 py-1 rounded-full bg-primary/20 text-primary text-xs font-bold">
                      {item.status}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-3">
                    {item.description}
                  </p>
                  <div className="text-xs font-mono text-primary bg-primary/10 px-2 py-1 rounded inline-block">
                    {item.metric}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Where We're Going */}
      <section ref={roadmapRef} className="py-20 px-6 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <motion.div
            className="mb-16 text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={roadmapInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold mb-4">Where We're Going</h2>
            <p className="text-xl text-muted-foreground">
              From NDA review to complete contract intelligence
            </p>
          </motion.div>

          <div className="space-y-6">
            {roadmap.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -40 }}
                animate={roadmapInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.15 }}
              >
                <Card className="p-6 border-2 border-border hover:border-primary/30 transition-colors group">
                  <div className="flex items-start gap-6">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center flex-shrink-0`}>
                      <item.icon className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-2xl font-bold group-hover:text-primary transition-colors">
                          {item.title}
                        </h3>
                        <span className="px-3 py-1 rounded-full bg-muted text-sm font-medium">
                          {item.phase}
                        </span>
                      </div>
                      <p className="text-muted-foreground leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Philosophy */}
      <section ref={philosophyRef} className="py-20 px-6">
        <div className="container mx-auto max-w-6xl">
          <motion.div
            className="mb-16 text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={philosophyInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold mb-4">Our Philosophy</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Legal AI should never require trust. It should guarantee it.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {philosophy.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                animate={philosophyInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.15 }}
              >
                <Card className="p-8 h-full border-2 border-border">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-6">
                    <item.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="mb-4">
                    <span className="text-sm font-bold text-primary uppercase tracking-wide">
                      {item.principle}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{item.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {item.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final Vision Statement */}
      <section className="py-20 px-6 bg-muted/30">
        <div className="container mx-auto max-w-4xl">
          <motion.div
            className="text-center p-12 rounded-3xl bg-gradient-to-br from-primary/10 via-chart-2/10 to-chart-3/10 border-2 border-primary/20"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
              Documents don't matter.
              <br />
              <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
                Decisions do.
              </span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              Lawyers shouldn't spend hours reading what AI can understand in seconds. 
              We're building the infrastructure layer that makes legal decisions instant.
            </p>
            <div className="inline-block p-4 rounded-xl bg-background/50 border border-border">
              <p className="text-sm font-medium text-primary">
                This isn't another AI tool. It's the infrastructure layer for legal decisions.
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </main>
  );
}

import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Our Vision | NDA Agent",
  description: "Explore the vision for NDA Agent, the private AI system for comprehensive legal decisions and contract lifecycle management.",
  alternates: {
    canonical: "/vision",
  },
};

export default function VisionLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { X, Check, ArrowRight } from "lucide-react";

const comparisons = [
  {
    before: "Reading 10+ pages of dense legal text",
    after: "10-second AI summary with risk scores",
  },
  {
    before: "Missing dangerous clauses buried in paragraphs",
    after: "Every risk automatically flagged and highlighted",
  },
  {
    before: "Waiting 2-3 days for lawyer review",
    after: "Instant analysis the moment you upload",
  },
  {
    before: "Hoping you didn't miss something important",
    after: "Clear decision: Sign, Negotiate, or Reject",
  },
  {
    before: "$500+ legal review fee per contract",
    after: "Unlimited reviews, one flat price",
  },
];

export function BeforeAfterSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  return (
    <section
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-muted/30"
    >
      <div className="container mx-auto max-w-6xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Stop signing blind
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            See exactly what changes when you know what you're signing
          </p>
        </motion.div>

        {/* Comparison Table */}
        <div className="space-y-4">
          {/* Header Row */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <motion.div
              className="p-6 rounded-2xl bg-destructive/10 border-2 border-destructive/20 text-center"
              initial={{ opacity: 0, x: -40 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <X className="w-8 h-8 text-destructive mx-auto mb-3" />
              <h3 className="text-2xl font-bold">Without KR8V</h3>
            </motion.div>
            <motion.div
              className="p-6 rounded-2xl bg-primary/10 border-2 border-primary/30 text-center"
              initial={{ opacity: 0, x: 40 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Check className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="text-2xl font-bold">With KR8V</h3>
            </motion.div>
          </div>

          {/* Comparison Rows */}
          {comparisons.map((item, index) => (
            <motion.div
              key={index}
              className="grid md:grid-cols-2 gap-6"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.6,
                delay: 0.4 + index * 0.1,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              {/* Before */}
              <div className="relative p-6 rounded-xl bg-card border-2 border-destructive/20 group hover:border-destructive/40 transition-colors">
                <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-destructive/20 flex items-center justify-center">
                  <X className="w-4 h-4 text-destructive" />
                </div>
                <p className="text-muted-foreground leading-relaxed pl-4">
                  {item.before}
                </p>
              </div>

              {/* Arrow (desktop) */}
              <div className="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                <motion.div
                  className="w-12 h-12 rounded-full bg-primary flex items-center justify-center shadow-lg"
                  whileHover={{ scale: 1.1 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <ArrowRight className="w-6 h-6 text-white" />
                </motion.div>
              </div>

              {/* After */}
              <div className="relative p-6 rounded-xl bg-card border-2 border-primary/30 group hover:border-primary/50 transition-colors">
                <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                  <Check className="w-4 h-4 text-primary" />
                </div>
                <p className="leading-relaxed pl-4 font-medium">
                  {item.after}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          className="mt-16 text-center p-8 rounded-3xl bg-gradient-to-br from-primary/5 via-chart-2/5 to-chart-3/5 border-2 border-primary/20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.2 }}
        >
          <h3 className="text-3xl font-bold mb-4">
            Review your first NDA in 60 seconds
          </h3>
          <p className="text-lg text-muted-foreground mb-6">
            No credit card. No installation. Just upload and see the difference.
          </p>
          <motion.button
            className="px-8 py-4 rounded-full bg-primary text-primary-foreground font-bold text-lg hover:bg-primary/90 transition-colors shadow-lg"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Try It Now — Free
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}

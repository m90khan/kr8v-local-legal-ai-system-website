"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Zap, Shield, Target, TrendingUp } from "lucide-react";

export function ScreenshotAnnotationSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  const annotations = [
    {
      icon: Zap,
      title: "Instant Risk Score",
      description: "72/100 safety rating calculated in real-time",
      position: "top-8 left-8",
      color: "primary",
    },
    {
      icon: Shield,
      title: "Clause-Level Highlighting",
      description: "Every problematic section visually flagged",
      position: "top-8 right-8",
      color: "chart-2",
    },
    {
      icon: Target,
      title: "Specific Recommendations",
      description: "Actionable fixes for each risk",
      position: "bottom-8 left-8",
      color: "chart-3",
    },
    {
      icon: TrendingUp,
      title: "Decision Clarity",
      description: "Clear next steps: Sign, Review, or Reject",
      position: "bottom-8 right-8",
      color: "chart-4",
    },
  ];

  return (
    <section
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-background"
    >
      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Everything you need
            <br />
            <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
              in one interface
            </span>
          </h2>
        </motion.div>

        {/* Main Screenshot Area */}
        <div className="relative max-w-6xl mx-auto">
          <motion.div
            className="relative rounded-3xl overflow-hidden border-2 border-primary/20 shadow-2xl bg-card"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            {/* Mock Interface */}
            <div className="aspect-video bg-gradient-to-br from-background via-muted/50 to-background p-12">
              <div className="grid grid-cols-3 gap-6 h-full">
                {/* Left Panel */}
                <div className="space-y-4">
                  <div className="h-12 rounded-lg bg-primary/20 border border-primary/30" />
                  <div className="h-32 rounded-lg bg-muted/50" />
                  <div className="h-32 rounded-lg bg-muted/50" />
                  <div className="h-24 rounded-lg bg-muted/50" />
                </div>

                {/* Center Panel - Document */}
                <div className="col-span-2 rounded-lg bg-background border-2 border-border p-6 relative">
                  {/* Document header */}
                  <div className="h-8 rounded bg-muted/50 mb-4 w-3/4" />
                  
                  {/* Document lines */}
                  <div className="space-y-2">
                    <div className="h-3 rounded bg-muted/30 w-full" />
                    <div className="h-3 rounded bg-muted/30 w-full" />
                    <div className="h-3 rounded bg-muted/30 w-5/6" />
                    <div className="h-3 rounded bg-muted/30 w-full" />
                    
                    {/* Highlighted risk clause */}
                    <div className="p-3 rounded-lg bg-destructive/10 border-l-4 border-destructive my-3">
                      <div className="h-3 rounded bg-destructive/30 w-full mb-2" />
                      <div className="h-3 rounded bg-destructive/30 w-4/5" />
                    </div>
                    
                    <div className="h-3 rounded bg-muted/30 w-full" />
                    <div className="h-3 rounded bg-muted/30 w-3/4" />
                    
                    {/* Another highlighted section */}
                    <div className="p-3 rounded-lg bg-yellow-500/10 border-l-4 border-yellow-500 my-3">
                      <div className="h-3 rounded bg-yellow-500/30 w-full mb-2" />
                      <div className="h-3 rounded bg-yellow-500/30 w-5/6" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Floating Annotations */}
          {annotations.map((annotation, index) => (
            <motion.div
              key={index}
              className={`absolute ${annotation.position} hidden lg:block`}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.6 + index * 0.15 }}
            >
              <div className="relative max-w-xs">
                {/* Connector Line */}
                <div className={`absolute w-16 h-0.5 bg-${annotation.color} ${
                  annotation.position.includes('right') ? 'right-full' : 'left-full'
                } top-1/2`} />
                
                {/* Annotation Card */}
                <motion.div
                  className={`p-4 rounded-xl bg-card border-2 border-${annotation.color}/30 shadow-lg backdrop-blur-sm`}
                  whileHover={{ scale: 1.05, borderColor: `hsl(var(--${annotation.color}))` }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-lg bg-${annotation.color}/20 flex items-center justify-center flex-shrink-0`}>
                      <annotation.icon className={`w-5 h-5 text-${annotation.color}`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-sm mb-1">{annotation.title}</h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {annotation.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Mobile Annotations */}
        <div className="lg:hidden mt-12 grid sm:grid-cols-2 gap-4">
          {annotations.map((annotation, index) => (
            <motion.div
              key={index}
              className="p-4 rounded-xl bg-card border-2 border-border"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.6 + index * 0.1 }}
            >
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-lg bg-${annotation.color}/20 flex items-center justify-center flex-shrink-0`}>
                  <annotation.icon className={`w-5 h-5 text-${annotation.color}`} />
                </div>
                <div>
                  <h4 className="font-bold text-sm mb-1">{annotation.title}</h4>
                  <p className="text-xs text-muted-foreground">{annotation.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

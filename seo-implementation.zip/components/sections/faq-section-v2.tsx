"use client";

import { motion, useInView, AnimatePresence } from "motion/react";
import { useRef, useState } from "react";
import { Plus, Minus } from "lucide-react";

const faqs = [
  {
    question: "Is this legally reliable? Can I trust the AI's analysis?",
    answer:
      "KR8V uses advanced NLP models trained on thousands of NDAs to identify risk patterns. However, we're clear: this is decision support, not legal advice. The AI flags risks and provides recommendations, but final decisions should involve human judgment. Think of it like spell-check for contracts — it catches what you'd miss, but you're still the author. Many of our customers use KR8V for first-pass review, then have their lawyer review only the flagged sections, cutting review time by 80%.",
    gradient: "from-primary to-chart-2",
  },
  {
    question: "Can I use this instead of a lawyer?",
    answer:
      "For standard NDAs, often yes. For complex negotiations or high-stakes contracts, no. KR8V excels at identifying problematic clauses in boilerplate agreements — the kind every startup signs 10+ times a year. It's not a replacement for legal counsel on major deals, custom agreements, or litigation. Our customers typically use KR8V for routine contracts and save lawyer time for strategic decisions.",
    gradient: "from-chart-2 to-chart-3",
  },
  {
    question: "Where does my data go? Who can see my contracts?",
    answer:
      "Nowhere. Literally. Your contracts are processed entirely on your infrastructure using local AI models (Ollama or similar). We don't have external API calls, we don't train models on your data, and we don't store copies on our servers. The contract text lives in your database, encrypted at rest. Even we (KR8V) can't see your documents. This is the whole point of local-first AI.",
    gradient: "from-chart-3 to-chart-4",
  },
  {
    question: "What happens if the AI makes a mistake?",
    answer:
      "That's why we show our work. Every risk is highlighted with the specific clause text, explanation, and reasoning. You can see exactly why the AI flagged something and make your own call. False positives are rare (under 5% in our testing), but when they happen, they're obvious. The bigger risk is false negatives — missing a problem clause. We optimize for catching everything, which means occasionally being overly cautious.",
    gradient: "from-chart-4 to-chart-5",
  },
  {
    question: "How long does analysis take? Can it handle complex contracts?",
    answer:
      "Typical NDAs: 10-15 seconds. Longer contracts (20+ pages): under 60 seconds. The AI reads faster than humans and doesn't get fatigued. We handle contracts up to 100 pages, though NDAs are usually 5-15 pages. For very complex agreements with nested dependencies, analysis may take 2-3 minutes but still faster than any human review.",
    gradient: "from-chart-5 to-primary",
  },
  {
    question: "Do you support contracts other than NDAs?",
    answer:
      "Currently, KR8V is optimized for NDAs and confidentiality agreements. We're expanding to employment agreements, vendor contracts, and MSAs in Q3 2024. Our AI engine is contract-agnostic — it's the rule sets and risk models that are specialized. If you need analysis for other contract types today, reach out to discuss custom training.",
    gradient: "from-primary to-chart-3",
  },
];

export function FaqSectionV2() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-muted/30"
    >
      <div className="container mx-auto max-w-4xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <span className="text-sm font-medium text-primary">FAQ</span>
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            The questions everyone asks
          </h2>
          <p className="text-xl text-muted-foreground">
            Honest answers to the hard questions about AI contract review
          </p>
        </motion.div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.6,
                delay: index * 0.1 + 0.3,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              <motion.div
                className="rounded-2xl border-2 border-border bg-card overflow-hidden cursor-pointer"
                onClick={() => toggleFaq(index)}
                whileHover={{ borderColor: "hsl(var(--primary) / 0.3)" }}
                transition={{ duration: 0.2 }}
              >
                {/* Question Header */}
                <div className="p-6 flex items-start justify-between gap-4">
                  <h3 className="text-lg font-bold flex-1">{faq.question}</h3>
                  <motion.div
                    className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center"
                    animate={{ rotate: openIndex === index ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    {openIndex === index ? (
                      <Minus className="w-4 h-4 text-primary" />
                    ) : (
                      <Plus className="w-4 h-4 text-primary" />
                    )}
                  </motion.div>
                </div>

                {/* Answer Panel */}
                <AnimatePresence initial={false}>
                  {openIndex === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                    >
                      <div className="px-6 pb-6">
                        <div
                          className={`w-12 h-1 bg-gradient-to-r ${faq.gradient} rounded-full mb-4`}
                        />
                        <p className="text-muted-foreground leading-relaxed">
                          {faq.answer}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          className="mt-16 text-center p-8 rounded-3xl bg-gradient-to-br from-primary/5 via-chart-2/5 to-chart-3/5 border-2 border-primary/20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <p className="text-lg font-medium mb-2">Still have questions?</p>
          <p className="text-muted-foreground mb-4">
            Talk to our team. We're nerds about contract AI and happy to explain how it all works.
          </p>
          <motion.button
            className="px-6 py-3 rounded-full bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Schedule a Call
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}

"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Shield, Lock, FileCheck, Database, Server, Eye } from "lucide-react";

const securityFeatures = [
  {
    icon: Shield,
    title: "AES Encryption",
    description: "Military-grade encryption for all stored documents",
  },
  {
    icon: Lock,
    title: "Bcrypt Hashing",
    description: "Secure access code and session management",
  },
  {
    icon: FileCheck,
    title: "Role-Based Access",
    description: "Granular permissions for admin, legal, and viewer roles",
  },
  {
    icon: Database,
    title: "Private Vector DB",
    description: "Local Qdrant instance, no cloud dependencies",
  },
  {
    icon: Server,
    title: "On-Premise Deploy",
    description: "Complete infrastructure control within your network",
  },
  {
    icon: Eye,
    title: "Audit Logging",
    description: "Immutable trail of every action and decision",
  },
];

const complianceStandards = [
  { name: "SOC 2 Type II", status: "Ready" },
  { name: "ISO 27001", status: "Ready" },
  { name: "GDPR", status: "Compliant" },
  { name: "HIPAA", status: "Ready" },
  { name: "CCPA", status: "Compliant" },
  { name: "SOX", status: "Ready" },
];

export function SecuritySection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  return (
    <section
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-background"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 -z-10 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)`,
            backgroundSize: "48px 48px",
          }}
        />
      </div>

      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <span className="text-sm font-medium text-primary">
              Security & Compliance
            </span>
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Enterprise-grade security
            <br />
            <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
              built into every layer
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Your data security is our foundation, not an afterthought
          </p>
        </motion.div>

        {/* Security Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {securityFeatures.map((feature, index) => (
            <motion.div
              key={index}
              className="p-6 rounded-2xl bg-card border-2 border-border hover:border-primary/50 transition-colors duration-300"
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.6,
                delay: index * 0.1 + 0.3,
                ease: [0.16, 1, 0.3, 1],
              }}
              whileHover={{ y: -4 }}
            >
              <motion.div
                className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-4"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <feature.icon className="w-6 h-6 text-primary" />
              </motion.div>
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Compliance Standards */}
        <motion.div
          className="max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.9 }}
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Compliance Ready</h3>
            <p className="text-muted-foreground">
              Designed to meet the most stringent compliance requirements
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {complianceStandards.map((standard, index) => (
              <motion.div
                key={index}
                className="p-6 rounded-2xl bg-gradient-to-br from-card to-muted/30 border-2 border-border text-center"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{
                  duration: 0.5,
                  delay: index * 0.1 + 1.2,
                  type: "spring",
                  stiffness: 100,
                }}
                whileHover={{ scale: 1.05 }}
              >
                <div className="text-xl font-bold mb-2">{standard.name}</div>
                <div className="inline-block px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-xs font-medium text-primary">
                  {standard.status}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Trust Statement */}
        <motion.div
          className="mt-20 p-12 rounded-3xl bg-gradient-to-br from-primary/5 via-chart-2/5 to-chart-3/5 border-2 border-primary/20 text-center"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.5 }}
        >
          <h3 className="text-2xl font-bold mb-4">
            Zero Trust Architecture
          </h3>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-6">
            We assume no implicit trust. Every action is authenticated, authorized,
            and audited. Your contracts remain encrypted at rest and in transit
            within your private network.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-6">
            {[
              "End-to-End Encryption",
              "No Third-Party Access",
              "Complete Audit Trail",
              "Private AI Models",
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="px-4 py-2 rounded-full bg-background border border-border"
                initial={{ opacity: 0, x: -20 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: 1.7 + index * 0.1 }}
              >
                <span className="text-sm font-medium">{feature}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

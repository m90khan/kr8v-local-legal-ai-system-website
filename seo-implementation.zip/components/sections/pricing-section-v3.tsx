"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check, ArrowRight, Sparkles, Users, Building2 } from "lucide-react";

const plans = [
  {
    name: "Solo",
    icon: Sparkles,
    forWho: "For founders & solopreneurs",
    description: "Review before you send to a lawyer",
    price: "$49",
    period: "/month",
    features: [
      "Up to 50 NDAs per month",
      "Instant risk analysis",
      "Clause highlighting",
      "Email support",
      "Export PDF reports",
    ],
    roi: "Catch issues early, save legal review time",
    cta: "Start Free Trial",
    color: "from-chart-2 to-chart-3",
    popular: false,
  },
  {
    name: "Team",
    icon: Users,
    forWho: "For startups & legal teams",
    description: "Reduce unnecessary legal spend on routine NDAs",
    price: "$199",
    period: "/month",
    features: [
      "Unlimited NDAs",
      "Advanced risk engine",
      "Policy alignment checks",
      "AI-powered rewrites",
      "Team collaboration (up to 10 users)",
      "Priority support",
      "Full audit trail",
      "API access",
    ],
    roi: "Save 15+ hours/month on first-pass review",
    cta: "Start Free Trial",
    color: "from-primary to-chart-2",
    popular: true,
  },
  {
    name: "Enterprise",
    icon: Building2,
    forWho: "For compliance-heavy organizations",
    description: "Scale legal operations efficiently",
    price: "Custom",
    period: "pricing",
    features: [
      "Everything in Team",
      "Unlimited users",
      "SSO & advanced security",
      "Custom AI model training",
      "On-premise deployment",
      "Dedicated success manager",
      "24/7 support with SLA",
      "Legal playbook integration",
      "Multi-department workflows",
    ],
    roi: "Streamline contract review across teams",
    cta: "Contact Sales",
    color: "from-chart-4 to-chart-5",
    popular: false,
  },
];

export function PricingSectionV3() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  return (
    <section
      id="pricing"
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-muted/30"
    >
      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <span className="text-sm font-medium text-primary">Pricing</span>
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Review smarter,
            <br />
            <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
              not harder
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Catch issues early. Send only flagged sections to your lawyer. Save time and legal fees.
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto mb-16">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 60 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.8,
                delay: index * 0.2 + 0.3,
                ease: [0.16, 1, 0.3, 1],
              }}
              className={plan.popular ? "md:-mt-4" : ""}
            >
              <motion.div
                className="h-full"
                whileHover={{ y: -8 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                <Card
                  className={`relative p-8 h-full overflow-hidden ${
                    plan.popular
                      ? "border-4 border-primary shadow-2xl"
                      : "border-2 border-border"
                  }`}
                >
                  {/* Popular Badge */}
                  {plan.popular && (
                    <motion.div
                      className="absolute top-0 right-0 px-6 py-2 bg-primary text-primary-foreground text-xs font-bold rounded-bl-2xl"
                      initial={{ x: 100, y: -100 }}
                      animate={isInView ? { x: 0, y: 0 } : {}}
                      transition={{ duration: 0.6, delay: 0.8 }}
                    >
                      MOST POPULAR
                    </motion.div>
                  )}

                  {/* Background Gradient */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${plan.color} opacity-5`}
                  />

                  {/* Icon & For Who */}
                  <div className="relative mb-6">
                    <div className="flex items-center gap-3 mb-2">
                      <div
                        className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center`}
                      >
                        <plan.icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold">{plan.name}</h3>
                      </div>
                    </div>
                    <p className="text-sm text-primary font-medium">{plan.forWho}</p>
                  </div>

                  {/* Description */}
                  <p className="text-muted-foreground mb-6">
                    {plan.description}
                  </p>

                  {/* Pricing */}
                  <div className="mb-6">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-muted-foreground">{plan.period}</span>
                    </div>
                  </div>

                  {/* ROI Highlight */}
                  <div className="mb-6 p-3 rounded-lg bg-primary/5 border border-primary/20">
                    <p className="text-sm font-medium text-primary">
                      💡 {plan.roi}
                    </p>
                  </div>

                  {/* Features */}
                  <div className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <motion.div
                        key={i}
                        className="flex items-start gap-3"
                        initial={{ opacity: 0, x: -20 }}
                        animate={isInView ? { opacity: 1, x: 0 } : {}}
                        transition={{ delay: index * 0.2 + 0.5 + i * 0.05 }}
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-gradient-to-br ${plan.color} flex items-center justify-center flex-shrink-0 mt-0.5`}
                        >
                          <Check className="w-3 h-3 text-white" />
                        </div>
                        <span className="text-sm leading-relaxed">{feature}</span>
                      </motion.div>
                    ))}
                  </div>

                  {/* CTA Button */}
                  <Button
                    className={`w-full rounded-full group ${
                      plan.popular
                        ? "bg-gradient-to-r from-primary to-chart-2 text-white"
                        : ""
                    }`}
                    variant={plan.popular ? "default" : "outline"}
                    size="lg"
                  >
                    {plan.cta}
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Card>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Trust Note */}
        <motion.div
          className="text-center max-w-3xl mx-auto"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 1.2 }}
        >
          <Card className="p-8 bg-gradient-to-br from-primary/5 to-chart-2/5 border-2 border-primary/20">
            <h3 className="text-xl font-bold mb-3">
              AI-assisted review, not AI replacement
            </h3>
            <p className="text-muted-foreground mb-4">
              KR8V helps you catch issues early so you can make informed decisions faster. 
              For complex negotiations, we recommend involving your legal counsel on flagged sections.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 text-sm">
              {["100% Private", "Local AI", "Zero Data Exposure", "Full Audit Trail"].map((item, i) => (
                <div key={i} className="px-3 py-1 rounded-full bg-primary/10 border border-primary/20 font-medium">
                  {item}
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

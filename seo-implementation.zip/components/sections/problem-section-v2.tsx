"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { AlertTriangle } from "lucide-react";

export function ProblemSectionV2() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  return (
    <section
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden"
    >
      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            NDAs hide risk
            <br />
            <span className="text-muted-foreground">in plain English</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Most founders sign without reading 80% of clauses.
            Here's why that's dangerous.
          </p>
        </motion.div>

        {/* Real NDA Example */}
        <motion.div
          className="max-w-4xl mx-auto mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <div className="relative">
            {/* Document Header */}
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                  <span className="text-2xl">📄</span>
                </div>
                <div>
                  <h3 className="font-bold">Standard Mutual NDA</h3>
                  <p className="text-sm text-muted-foreground">12 pages · Received from investor</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Time to read properly</div>
                <div className="text-2xl font-bold">45 minutes</div>
              </div>
            </div>

            {/* NDA Snippet with Highlighted Risks */}
            <div className="relative p-8 rounded-2xl bg-card border-2 border-border overflow-hidden">
              {/* Page indicator */}
              <div className="absolute top-4 right-4 text-xs text-muted-foreground">
                Page 7 of 12
              </div>

              <div className="space-y-6 font-mono text-sm leading-relaxed">
                <p className="text-muted-foreground">
                  <span className="text-foreground/50">6.1</span> The Receiving Party agrees that all Confidential Information
                  shall remain the exclusive property of the Disclosing Party.
                </p>

                {/* Hidden Risk #1 */}
                <motion.div
                  className="relative p-4 rounded-lg bg-destructive/5 border-l-4 border-destructive"
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.6 }}
                >
                  <div className="absolute -left-2 top-3 w-6 h-6 rounded-full bg-destructive flex items-center justify-center">
                    <AlertTriangle className="w-4 h-4 text-white" />
                  </div>
                  <p className="mb-2">
                    <span className="text-foreground/50">6.2</span>{" "}
                    <span className="bg-destructive/20 px-1">
                      The Receiving Party shall not, without prior written consent, 
                      directly or indirectly solicit, hire, or engage any employee, 
                      contractor, or consultant of the Disclosing Party
                    </span>{" "}
                    for a period extending beyond the term of this Agreement.
                  </p>
                  <div className="mt-3 flex items-start gap-2 text-xs">
                    <span className="px-2 py-1 rounded bg-destructive/20 text-destructive font-bold">
                      🚨 HIGH RISK
                    </span>
                    <span className="text-destructive">
                      Indefinite non-solicitation — blocks hiring even after NDA ends
                    </span>
                  </div>
                </motion.div>

                <p className="text-muted-foreground">
                  <span className="text-foreground/50">6.3</span> Each party acknowledges that unauthorized 
                  disclosure may cause irreparable harm.
                </p>

                {/* Hidden Risk #2 */}
                <motion.div
                  className="relative p-4 rounded-lg bg-yellow-500/5 border-l-4 border-yellow-500"
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.8 }}
                >
                  <div className="absolute -left-2 top-3 w-6 h-6 rounded-full bg-yellow-500 flex items-center justify-center">
                    <AlertTriangle className="w-4 h-4 text-white" />
                  </div>
                  <p className="mb-2">
                    <span className="text-foreground/50">6.4</span>{" "}
                    <span className="bg-yellow-500/20 px-1">
                      The Receiving Party agrees that the Disclosing Party shall be entitled to 
                      equitable relief, including injunction and specific performance,
                    </span>{" "}
                    in addition to all other remedies available at law or in equity.
                  </p>
                  <div className="mt-3 flex items-start gap-2 text-xs">
                    <span className="px-2 py-1 rounded bg-yellow-500/20 text-yellow-600 dark:text-yellow-400 font-bold">
                      ⚠️ MEDIUM RISK
                    </span>
                    <span className="text-yellow-600 dark:text-yellow-400">
                      Automatic injunction rights — can freeze your business instantly
                    </span>
                  </div>
                </motion.div>

                <p className="text-muted-foreground">
                  <span className="text-foreground/50">6.5</span> This Agreement shall be governed by 
                  the laws of Delaware without regard to conflicts of law principles.
                </p>
              </div>

              {/* Bottom note */}
              <div className="mt-8 pt-6 border-t border-border text-sm text-muted-foreground text-center">
                ... and 6 more pages of legal text
              </div>
            </div>
          </div>
        </motion.div>

        {/* Real Statistics */}
        <motion.div
          className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
        >
          {[
            {
              stat: "80%",
              label: "of NDAs contain at least one problematic clause",
              color: "destructive",
            },
            {
              stat: "3 days",
              label: "average time for legal review (if you have a lawyer)",
              color: "yellow-500",
            },
            {
              stat: "45 min",
              label: "time needed to carefully read a 12-page NDA",
              color: "primary",
            },
          ].map((item, index) => (
            <motion.div
              key={index}
              className="p-6 rounded-2xl bg-card border-2 border-border text-center"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 1 + index * 0.1, type: "spring", stiffness: 100 }}
              whileHover={{ y: -4, borderColor: `hsl(var(--${item.color}))` }}
            >
              <div className={`text-5xl font-bold mb-3 text-${item.color}`}>
                {item.stat}
              </div>
              <div className="text-sm text-muted-foreground leading-relaxed">
                {item.label}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

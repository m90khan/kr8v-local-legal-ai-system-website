"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Card } from "@/components/ui/card";
import {
  Lock,
  Scale,
  Brain,
  TrendingUp,
  FileCheck,
  RefreshCw,
} from "lucide-react";

const features = [
  {
    icon: Lock,
    title: "Private Infrastructure",
    description: "Runs entirely inside your network. Your contracts never leave your control.",
    gradient: "from-primary to-chart-2",
  },
  {
    icon: Scale,
    title: "Decision Engine",
    description: "Not just analysis — clear approval decisions with legal context.",
    gradient: "from-chart-2 to-chart-3",
  },
  {
    icon: Brain,
    title: "Reference Intelligence",
    description: "Learns from your contracts and company-specific legal standards.",
    gradient: "from-chart-3 to-chart-4",
  },
  {
    icon: TrendingUp,
    title: "Risk Heatmaps",
    description: "Visual clause-level risk highlighting for instant comprehension.",
    gradient: "from-chart-4 to-chart-5",
  },
  {
    icon: FileCheck,
    title: "Audit Logs",
    description: "Every action tracked and verifiable for compliance requirements.",
    gradient: "from-chart-5 to-primary",
  },
  {
    icon: RefreshCw,
    title: "Rewrite Engine",
    description: "Fix risky clauses instantly with policy-aligned alternatives.",
    gradient: "from-primary to-chart-3",
  },
];

export function FeaturesSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  return (
    <section
      id="features"
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-background"
    >
      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <span className="text-sm font-medium text-primary">Features</span>
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Everything you need for
            <br />
            <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
              confident legal decisions
            </span>
          </h2>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 60 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.8,
                delay: index * 0.1 + 0.3,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              <motion.div
                className="group h-full"
                whileHover={{ y: -8 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                <Card className="relative p-8 h-full overflow-hidden border-2 border-border hover:border-primary/50 transition-colors duration-300">
                  {/* Animated Background Gradient */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
                    initial={false}
                  />

                  {/* Icon Container */}
                  <motion.div
                    className="relative mb-6"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: "spring", stiffness: 400, damping: 17 }}
                  >
                    <div className="relative w-14 h-14">
                      {/* Glow Effect */}
                      <motion.div
                        className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} rounded-2xl blur-xl opacity-0 group-hover:opacity-50 transition-opacity duration-500`}
                      />
                      {/* Icon Box */}
                      <div className={`relative w-full h-full rounded-2xl bg-gradient-to-br ${feature.gradient} p-3 flex items-center justify-center`}>
                        <feature.icon className="w-full h-full text-white" />
                      </div>
                    </div>
                  </motion.div>

                  {/* Content */}
                  <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors duration-300">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>

                  {/* Bottom Accent */}
                  <motion.div
                    className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${feature.gradient}`}
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: index * 0.1 + 0.5 }}
                    style={{ transformOrigin: "left" }}
                  />

                  {/* Hover Shine Effect */}
                  <motion.div
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{
                      background:
                        "linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%)",
                      backgroundSize: "200% 200%",
                    }}
                    animate={{
                      backgroundPosition: ["0% 0%", "200% 200%"],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "linear",
                    }}
                  />
                </Card>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Additional Feature Highlight */}
        <motion.div
          className="mt-16"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <Card className="p-12 bg-gradient-to-br from-primary/5 via-chart-2/5 to-chart-3/5 border-2 border-primary/20">
            <div className="text-center max-w-3xl mx-auto">
              <h3 className="text-3xl font-bold mb-4">
                Built for Legal Teams, Secured by Design
              </h3>
              <p className="text-lg text-muted-foreground">
                KR8V combines the power of modern AI with the security and control your legal team demands. 
                No compromises, no cloud dependencies, no data exposure.
              </p>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

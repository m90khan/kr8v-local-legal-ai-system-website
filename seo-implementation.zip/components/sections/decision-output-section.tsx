"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { CheckCircle, AlertTriangle, XCircle, ArrowRight } from "lucide-react";

export function DecisionOutputSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  const decisions = [
    {
      icon: CheckCircle,
      status: "Safe to Sign",
      color: "green",
      description: "Standard clauses, minimal risk, ready to execute",
      example: "Mutual NDA with 2-year term and standard confidentiality provisions",
      action: "Sign with confidence",
      gradient: "from-green-500 to-emerald-500",
      bgColor: "bg-green-500/5",
      borderColor: "border-green-500/20 hover:border-green-500/40",
    },
    {
      icon: AlertTriangle,
      status: "Needs Review",
      color: "yellow",
      description: "Some clauses require attention before signing",
      example: "Non-standard liability clause in section 4.2 needs clarification",
      action: "Review flagged sections",
      gradient: "from-yellow-500 to-orange-500",
      bgColor: "bg-yellow-500/5",
      borderColor: "border-yellow-500/30 hover:border-yellow-500/50",
    },
    {
      icon: XCircle,
      status: "High Risk",
      color: "red",
      description: "Dangerous clauses detected, do not sign without changes",
      example: "Indefinite non-compete and unlimited liability exposure",
      action: "Request modifications",
      gradient: "from-red-500 to-rose-500",
      bgColor: "bg-red-500/5",
      borderColor: "border-red-500/30 hover:border-red-500/50",
    },
  ];

  return (
    <section
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-background"
    >
      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <span className="text-sm font-medium text-primary">Decision Intelligence</span>
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Get a clear decision
            <br />
            <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
              in seconds
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Not just analysis. A clear recommendation: Safe to Sign, Needs Review, or High Risk.
          </p>
        </motion.div>

        {/* Decision Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {decisions.map((decision, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 60 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.8,
                delay: index * 0.2 + 0.3,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              <motion.div
                className={`relative p-8 rounded-3xl ${decision.bgColor} border-2 ${decision.borderColor} transition-all duration-300 h-full group`}
                whileHover={{ y: -8, scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                {/* Gradient Background */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${decision.gradient} opacity-0 group-hover:opacity-5 transition-opacity rounded-3xl`}
                />

                {/* Icon */}
                <div className="relative mb-6">
                  <decision.icon className={`w-16 h-16 text-${decision.color}-500`} />
                </div>

                {/* Status */}
                <h3 className={`text-3xl font-bold mb-3 text-${decision.color}-600 dark:text-${decision.color}-400`}>
                  {decision.status}
                </h3>

                {/* Description */}
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  {decision.description}
                </p>

                {/* Example */}
                <div className="p-4 rounded-xl bg-background/50 border border-border mb-4">
                  <p className="text-sm italic text-muted-foreground">
                    "{decision.example}"
                  </p>
                </div>

                {/* Action */}
                <div className="flex items-center gap-2 text-sm font-medium">
                  <span className={`text-${decision.color}-600 dark:text-${decision.color}-400`}>
                    {decision.action}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </div>

                {/* Bottom Accent */}
                <motion.div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${decision.gradient} rounded-b-3xl`}
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.2 + 0.5 }}
                  style={{ transformOrigin: "left" }}
                />
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Why This Matters */}
        <motion.div
          className="max-w-4xl mx-auto text-center p-8 rounded-3xl bg-gradient-to-br from-primary/5 via-chart-2/5 to-chart-3/5 border-2 border-primary/20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <h3 className="text-2xl font-bold mb-4">
            This is the feature that changes everything
          </h3>
          <p className="text-lg text-muted-foreground mb-6">
            Most tools give you analysis. KR8V gives you a decision. You don't need to be a lawyer 
            to know if an NDA is safe — the AI tells you directly.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-primary" />
              <span>Clear recommendation</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-primary" />
              <span>Specific reasoning</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-primary" />
              <span>Suggested fixes</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

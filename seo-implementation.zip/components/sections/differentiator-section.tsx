"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Cloud, Server, X, Check } from "lucide-react";

const comparisons = [
  {
    feature: "Data stays on-premise",
    traditional: false,
    kr8v: true,
  },
  {
    feature: "AI analysis",
    traditional: true,
    kr8v: true,
  },
  {
    feature: "Company policy alignment",
    traditional: false,
    kr8v: true,
  },
  {
    feature: "Full audit trail",
    traditional: false,
    kr8v: true,
  },
  {
    feature: "No vendor lock-in",
    traditional: false,
    kr8v: true,
  },
  {
    feature: "Compliance-ready",
    traditional: false,
    kr8v: true,
  },
];

export function DifferentiatorSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  return (
    <section
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-background"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 -z-10 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)`,
            backgroundSize: "40px 40px",
          }}
        />
      </div>

      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <span className="text-sm font-medium text-primary">
              What Makes Us Different
            </span>
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Unlike cloud AI tools,
            <br />
            <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
              KR8V never sends your contracts outside your control
            </span>
          </h2>
        </motion.div>

        {/* Visual Comparison */}
        <div className="max-w-5xl mx-auto">
          {/* Headers */}
          <div className="grid grid-cols-3 gap-6 mb-8">
            <div className="col-span-1" />
            <motion.div
              className="text-center p-6 rounded-2xl bg-muted/50 border border-border"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Cloud className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <h3 className="font-bold text-lg">Cloud AI Tools</h3>
            </motion.div>
            <motion.div
              className="text-center p-6 rounded-2xl bg-gradient-to-br from-primary/10 to-chart-2/10 border-2 border-primary/30"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Server className="w-8 h-8 mx-auto mb-2 text-primary" />
              <h3 className="font-bold text-lg">KR8V</h3>
            </motion.div>
          </div>

          {/* Comparison Rows */}
          <div className="space-y-3">
            {comparisons.map((item, index) => (
              <motion.div
                key={index}
                className="grid grid-cols-3 gap-6 items-center p-4 rounded-2xl bg-card border border-border hover:border-primary/30 transition-colors duration-300"
                initial={{ opacity: 0, x: -40 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{
                  duration: 0.6,
                  delay: index * 0.1 + 0.5,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                <div className="font-medium">{item.feature}</div>
                
                {/* Traditional Tools */}
                <div className="flex justify-center">
                  <motion.div
                    whileHover={{ scale: 1.2, rotate: item.traditional ? 0 : -10 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    {item.traditional ? (
                      <Check className="w-6 h-6 text-muted-foreground" />
                    ) : (
                      <X className="w-6 h-6 text-destructive" />
                    )}
                  </motion.div>
                </div>

                {/* KR8V */}
                <div className="flex justify-center">
                  <motion.div
                    whileHover={{ scale: 1.2 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    {item.kr8v ? (
                      <Check className="w-6 h-6 text-primary" />
                    ) : (
                      <X className="w-6 h-6 text-destructive" />
                    )}
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Bottom Highlight */}
          <motion.div
            className="mt-12 p-8 rounded-3xl bg-gradient-to-br from-primary/5 via-chart-2/5 to-chart-3/5 border-2 border-primary/20 text-center"
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 1.2 }}
          >
            <h3 className="text-2xl font-bold mb-4">Your Data, Your Infrastructure, Your Control</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              KR8V runs entirely within your network boundaries. No external API calls, 
              no cloud dependencies, no data exposure to third parties.
            </p>
          </motion.div>
        </div>

        {/* Visual Network Diagram */}
        <motion.div
          className="mt-20 max-w-4xl mx-auto"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1, delay: 1.5 }}
        >
          <div className="relative p-12 rounded-3xl border-2 border-primary/20 bg-gradient-to-br from-card to-muted/30">
            <h4 className="text-xl font-bold text-center mb-8">
              Traditional vs KR8V Data Flow
            </h4>
            
            <div className="grid md:grid-cols-2 gap-12">
              {/* Traditional Flow */}
              <div className="space-y-4">
                <div className="text-center font-medium text-sm text-muted-foreground mb-4">
                  Cloud AI Tools
                </div>
                <div className="flex flex-col gap-3">
                  {["Your Data", "→ Internet", "→ Cloud API", "→ Third Party"].map((step, i) => (
                    <motion.div
                      key={i}
                      className={`p-3 rounded-lg text-center ${
                        i === 0 ? "bg-primary/20 border border-primary/30" : "bg-destructive/10 border border-destructive/20"
                      }`}
                      initial={{ opacity: 0, x: -20 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ delay: 1.7 + i * 0.1 }}
                    >
                      {step}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* KR8V Flow */}
              <div className="space-y-4">
                <div className="text-center font-medium text-sm text-muted-foreground mb-4">
                  KR8V
                </div>
                <div className="flex flex-col gap-3">
                  {["Your Data", "→ Local AI", "→ Your Network", "→ Your Control"].map((step, i) => (
                    <motion.div
                      key={i}
                      className="p-3 rounded-lg bg-primary/20 border border-primary/30 text-center"
                      initial={{ opacity: 0, x: 20 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ delay: 1.7 + i * 0.1 }}
                    >
                      {step}
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

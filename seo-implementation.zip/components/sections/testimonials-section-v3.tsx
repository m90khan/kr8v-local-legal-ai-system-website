"use client";

import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, Quote, Star } from "lucide-react";

const testimonials = [
  {
    quote: "Saved me 3 hours reviewing a single NDA before signing with a client. Found an indefinite non-compete clause buried in section 8 that I would have missed.",
    author: "Alex Chen",
    role: "Founder",
    company: "SaaS Startup (Stealth)",
    metric: "3 hours saved",
    gradient: "from-primary to-chart-2",
  },
  {
    quote: "We review 40+ NDAs a month. KR8V catches the problematic ones in seconds. Our legal team now only reviews the 12% flagged as high-risk instead of all 40.",
    author: "Sarah Martinez",
    role: "Head of Legal Operations",
    company: "Series B Fintech",
    metric: "88% reduction in review volume",
    gradient: "from-chart-2 to-chart-3",
  },
  {
    quote: "Flagged a liability clause that would have exposed us to unlimited damages. Our lawyer confirmed it — that clause alone could have cost us millions in a dispute.",
    author: "James Park",
    role: "VP of Business Development",
    company: "Healthcare Tech Company",
    metric: "Avoided potential lawsuit",
    gradient: "from-chart-3 to-chart-4",
  },
  {
    quote: "Before KR8V, I'd sign NDAs without reading them fully. Now I know exactly what I'm agreeing to. Caught 2 non-standard clauses in NDAs from 'trusted' partners.",
    author: "Maya Patel",
    role: "Solo Founder",
    company: "E-commerce Platform",
    metric: "100% informed decisions",
    gradient: "from-chart-4 to-primary",
  },
];

export function TestimonialsSectionV3() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section
      ref={containerRef}
      className="py-32 px-6 relative overflow-hidden bg-background"
    >
      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.5 }}
          >
            <span className="text-sm font-medium text-primary">What People Say</span>
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Real results from
            <br />
            <span className="bg-gradient-to-r from-primary via-chart-2 to-chart-3 bg-clip-text text-transparent">
              real teams
            </span>
          </h2>
        </motion.div>

        {/* Testimonial Carousel */}
        <div className="relative max-w-5xl mx-auto">
          <div className="relative overflow-hidden">
            <motion.div
              className="flex"
              animate={{ x: `-${currentIndex * 100}%` }}
              transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0 px-4">
                  <Card className="p-12 relative overflow-hidden border-2 border-border hover:border-primary/30 transition-colors">
                    {/* Background Gradient */}
                    <div
                      className={`absolute inset-0 bg-gradient-to-br ${testimonial.gradient} opacity-5`}
                    />

                    {/* Stars */}
                    <motion.div
                      className="flex gap-1 mb-6 justify-center"
                      initial={{ scale: 0 }}
                      animate={isInView ? { scale: 1 } : {}}
                      transition={{ duration: 0.6, delay: 0.3 }}
                    >
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                      ))}
                    </motion.div>

                    {/* Quote Icon */}
                    <motion.div
                      className="mb-6 flex justify-center"
                      initial={{ scale: 0, rotate: -180 }}
                      animate={isInView ? { scale: 1, rotate: 0 } : {}}
                      transition={{ duration: 0.6, delay: 0.2 }}
                    >
                      <Quote className="w-12 h-12 text-primary/30" />
                    </motion.div>

                    {/* Quote Text */}
                    <p className="text-xl md:text-2xl font-medium mb-8 leading-relaxed relative z-10 text-center">
                      "{testimonial.quote}"
                    </p>

                    {/* Metric Highlight */}
                    <div className="mb-6 flex justify-center">
                      <div className="px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
                        <span className="text-sm font-bold text-primary">
                          📊 {testimonial.metric}
                        </span>
                      </div>
                    </div>

                    {/* Author Info */}
                    <div className="relative z-10 text-center">
                      <div className="font-bold text-lg mb-1">{testimonial.author}</div>
                      <div className="text-muted-foreground text-sm">
                        {testimonial.role}
                      </div>
                      <div className="text-muted-foreground/70 text-sm">
                        {testimonial.company}
                      </div>
                    </div>
                  </Card>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <motion.button
              onClick={prevTestimonial}
              className="w-12 h-12 rounded-full border-2 border-border bg-card flex items-center justify-center hover:border-primary hover:bg-primary/10 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronLeft className="w-6 h-6" />
            </motion.button>

            {/* Dots Indicator */}
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <motion.button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`h-2 rounded-full transition-all ${
                    index === currentIndex
                      ? "bg-primary w-8"
                      : "bg-muted-foreground/30 w-2"
                  }`}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.8 }}
                />
              ))}
            </div>

            <motion.button
              onClick={nextTestimonial}
              className="w-12 h-12 rounded-full border-2 border-border bg-card flex items-center justify-center hover:border-primary hover:bg-primary/10 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronRight className="w-6 h-6" />
            </motion.button>
          </div>
        </div>

        {/* Trust Footer */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <p className="text-muted-foreground text-sm mb-4">
            Join 100+ legal teams using KR8V to review contracts faster
          </p>
          <div className="flex flex-wrap items-center justify-center gap-8 grayscale opacity-50">
            {/* Placeholder for company logos */}
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="w-24 h-12 rounded bg-muted/30" />
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
